# Arduino

## This where all the Communication test on the Arduino are

Use my_... for the tests

Remember to connect your GNDs on all tests

[Communication test website](https://www.circuitbasics.com/arduino/)