var searchData=
[
  ['lcd_5fscreen_5fdev_181',['lcd_screen_dev',['../spi__test__prog_8c.html#a91f5baec8594e14ef1799a74e537dfaa',1,'lcd_screen_dev():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a91f5baec8594e14ef1799a74e537dfaa',1,'lcd_screen_dev():&#160;spi_test_prog.c']]]
];
