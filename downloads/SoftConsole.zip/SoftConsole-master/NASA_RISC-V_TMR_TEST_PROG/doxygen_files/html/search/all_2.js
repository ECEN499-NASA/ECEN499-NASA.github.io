var searchData=
[
  ['base_5faddr_4',['base_addr',['../structspi__instance.html#a33fadb8ca646c00e54609a7858be737b',1,'spi_instance']]],
  ['block_5frx_5fhandler_5',['block_rx_handler',['../structspi__instance.html#af64bb177590ae54be4fe53992961049c',1,'spi_instance']]],
  ['buffer_5fsize_6',['BUFFER_SIZE',['../i2c__test__routine_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'i2c_test_routine.h']]],
  ['byte_5fto_5fdec_5fstring_7',['byte_to_dec_string',['../user__handler_8c.html#afe3cfeebce751c4563a0b7b103c5a80d',1,'byte_to_dec_string(uint8_t byte, char dec_string[4]):&#160;user_handler.c'],['../user__handler_8h.html#afe3cfeebce751c4563a0b7b103c5a80d',1,'byte_to_dec_string(uint8_t byte, char dec_string[4]):&#160;user_handler.c']]]
];
