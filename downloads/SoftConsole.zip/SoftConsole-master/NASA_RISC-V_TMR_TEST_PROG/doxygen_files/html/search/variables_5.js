var searchData=
[
  ['g_5fcore_5fi2c_179',['g_core_i2c',['../i2c__test__routine_8h.html#a6556630a300334a3d6617db7e58d386b',1,'i2c_test_routine.h']]],
  ['g_5fuart_180',['g_uart',['../user__handler_8h.html#a2700cde8d3662ef58b647d5e4b14e18b',1,'g_uart():&#160;main.c'],['../spi__test__prog_8h.html#a2700cde8d3662ef58b647d5e4b14e18b',1,'g_uart():&#160;main.c'],['../i2c__test__routine_8h.html#a2700cde8d3662ef58b647d5e4b14e18b',1,'g_uart():&#160;main.c']]]
];
