var searchData=
[
  ['riscv_5fspi_49',['riscv_spi',['../spi__test__prog_8h.html#a250197ee931f58248dd31b2028d1611d',1,'spi_test_prog.h']]],
  ['run_5fi2c_5ftest_50',['run_i2c_test',['../i2c__test__routine_8c.html#a62adf38824017f05dad325443c32cccf',1,'run_i2c_test(void):&#160;i2c_test_routine.c'],['../i2c__test__routine_8h.html#a62adf38824017f05dad325443c32cccf',1,'run_i2c_test(void):&#160;i2c_test_routine.c']]],
  ['rx_5fframe_51',['rx_frame',['../structspi__instance.html#af2612d057b2a4ad5fb2e0742f300bfc1',1,'spi_instance']]]
];
