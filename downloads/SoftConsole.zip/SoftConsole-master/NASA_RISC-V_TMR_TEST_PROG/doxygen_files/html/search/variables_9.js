var searchData=
[
  ['selected_5fdev_185',['selected_dev',['../spi__test__prog_8h.html#a2e074965d77b7cc2854b2b89748b666a',1,'spi_test_prog.h']]],
  ['selected_5fdev_5fid_186',['selected_dev_id',['../spi__test__prog_8h.html#a29a1d98fbd9a5932b4e319345046e3b3',1,'spi_test_prog.h']]],
  ['slave_5frx_5fbuffer_187',['slave_rx_buffer',['../structspi__instance.html#ac3dfc213020b0deab82d5fdf21b99e88',1,'spi_instance']]],
  ['slave_5frx_5fidx_188',['slave_rx_idx',['../structspi__instance.html#a0775f00dad88d150cca5212bf8cbc984',1,'spi_instance']]],
  ['slave_5frx_5fsize_189',['slave_rx_size',['../structspi__instance.html#a3fee7a8823bba91ff1633ae1dcdc7630',1,'spi_instance']]],
  ['slave_5ftx_5fbuffer_190',['slave_tx_buffer',['../structspi__instance.html#ae8d38e5d708f1b70756f309452356297',1,'spi_instance']]],
  ['slave_5ftx_5fframe_191',['slave_tx_frame',['../structspi__instance.html#a2f151e4bc185fe5b29b7a163c8394a39',1,'spi_instance']]],
  ['slave_5ftx_5fframe_5fhandler_192',['slave_tx_frame_handler',['../structspi__instance.html#ae6485afd811699de30c1979135e73d64',1,'spi_instance']]],
  ['slave_5ftx_5fidx_193',['slave_tx_idx',['../structspi__instance.html#a07c68baba60c5ff91c66de22c323f7b7',1,'spi_instance']]],
  ['slave_5ftx_5fsize_194',['slave_tx_size',['../structspi__instance.html#a3417da3952ed478ca4c65e165606c9e3',1,'spi_instance']]],
  ['slave_5fxfer_5fmode_195',['slave_xfer_mode',['../structspi__instance.html#a1fd483af054c9f14c49d2476567ce7fc',1,'spi_instance']]],
  ['spi_196',['spi',['../structspi__dev.html#ae5a31ddc8d2628abca254a9b30a7acbd',1,'spi_dev']]],
  ['spi_5fcommand_5fbyte_197',['spi_command_byte',['../spi__test__prog_8h.html#a46dcef2d0c8a10b1934f5c812ac28895',1,'spi_test_prog.h']]],
  ['spi_5fsel_198',['spi_sel',['../structspi__dev.html#af481a62e80b304163756fd6f74c745fc',1,'spi_dev']]]
];
