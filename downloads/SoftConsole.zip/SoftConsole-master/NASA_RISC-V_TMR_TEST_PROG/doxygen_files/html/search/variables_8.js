var searchData=
[
  ['riscv_5fspi_183',['riscv_spi',['../spi__test__prog_8h.html#a250197ee931f58248dd31b2028d1611d',1,'spi_test_prog.h']]],
  ['rx_5fframe_184',['rx_frame',['../structspi__instance.html#af2612d057b2a4ad5fb2e0742f300bfc1',1,'spi_instance']]]
];
