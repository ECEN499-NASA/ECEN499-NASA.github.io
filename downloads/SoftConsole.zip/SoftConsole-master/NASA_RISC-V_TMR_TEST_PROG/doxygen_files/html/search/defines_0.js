var searchData=
[
  ['buffer_5fsize_202',['BUFFER_SIZE',['../i2c__test__routine_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'i2c_test_routine.h']]]
];
