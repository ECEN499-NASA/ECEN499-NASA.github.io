var searchData=
[
  ['accelerometer_5fdev_2',['accelerometer_dev',['../spi__test__prog_8c.html#a5779eee5a7019ec0d0b15312d53bcdd9',1,'accelerometer_dev():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a5779eee5a7019ec0d0b15312d53bcdd9',1,'accelerometer_dev():&#160;spi_test_prog.c']]],
  ['adc_5fdev_3',['adc_dev',['../spi__test__prog_8c.html#a467bd423905e83ac180fe7dbf81291bf',1,'adc_dev():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a467bd423905e83ac180fe7dbf81291bf',1,'adc_dev():&#160;spi_test_prog.c']]]
];
